(ns tfidf-cascalog.core-test
  (:use clojure.test
        tfidf-cascalog.core))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
