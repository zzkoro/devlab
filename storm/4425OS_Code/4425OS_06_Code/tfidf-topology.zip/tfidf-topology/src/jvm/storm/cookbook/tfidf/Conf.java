package storm.cookbook.tfidf;


public class Conf {
    public static final String REDIS_HOST_KEY = "redisHost";
    public static final String REDIS_PORT_KEY = "redisPort";
    public static final String DEFAULT_JEDIS_PORT = "6379";
}
