#!/bin/sh 

python sendOrders.py 100 10